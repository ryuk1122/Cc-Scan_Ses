import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  FlatList,
  Animated,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useFocusEffect, useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import * as FileSystem from "expo-file-system";
import { CameraView, useCameraPermissions } from "expo-camera";

import { theme } from "@/src/theme";
import { useSession } from "@/src/ctx/session";
import { useEvento } from "@/src/ctx/evento";
import { api } from "@/src/utils/api";
import { extractCedula, parsePdf417 } from "@/src/utils/cedula";
import { LocalCedulaCamera, localScannerAvailable } from "@/src/components/LocalCedulaCamera";
import { validateMrz, isMrzText } from "@/src/utils/mrzValidation";

const PILL_TIMEOUT = 2500;
const RAW_SCAN_COOLDOWN_MS = 900;
const SCANNER_REARM_DELAY_MS = 450;
const ABSOLUTE_FILL = { position: "absolute" as const, top: 0, right: 0, bottom: 0, left: 0 };
const COLOMBIAN_DASH_PAYLOAD_RE = /(?:^|[^A-Z0-9])([A-Z])-\d{5,8}-\d{5,10}-([MF])-(\d{5,11})-((?:19|20)\d{6})(?:[^0-9]|$)/i;
const QR_ID_KEY_RE = /(?:^|[?&#;,\s{\["'])\s*(?:nuip|cedula|c[eé]dula|cc|doc|documento|document_number|documentnumber|numero_documento|n[uú]mero|numero|nro|no|identificacion|identificaci[oó]n|id)\s*["']?\s*[:=/#-]\s*["']?([0-9][0-9\s.,-]{3,20}[0-9])/i;
const QR_PREFIX_RE = /(?:^|[^A-Z0-9])(?:CC|NUIP|DOC|CEDULA|DOCUMENTO|ID)\s*[:#-]?\s*([0-9][0-9\s.,-]{3,20}[0-9])(?:[^0-9]|$)/i;

type AfiliadoPreview = {
  encontrado: boolean;
  error?: boolean;
  cedula: string;
  afiliado?: {
    nombre?: string;
    sede?: string;
    municipio?: string;
    cargo?: string;
    zona?: string;
    titulo?: string;
    aportes_al_dia?: boolean | null;
    estado_aportes?: string;
  };
};

type DocumentPreview = {
  cedula: string;
  nombre: string;
  fecha: string;
  fechaExpiracion?: string;
  fuente?: string;
  mrzValido?: boolean;
};

type Mode = "camera" | "manual";
type ParsedCedulaResult = ReturnType<typeof parsePdf417>;
type ServerParsedCedula = Partial<Pick<
  ParsedCedulaResult,
  | "cedula"
  | "nombres"
  | "primer_apellido"
  | "segundo_apellido"
  | "genero"
  | "fecha_nacimiento"
  | "fecha_expiracion"
  | "tipo_sangre"
  | "mrz_valido"
>>;
type OcrReadResult = { raw: string; serverParsed?: ServerParsedCedula; error?: string };
type PrintPayload = { nombre: string; cargo: string; municipio: string; sede?: string };
type ScanFeedback = { kind: "ok" | "dup" | "err"; title: string; detail: string; cedula?: string; municipio?: string };

function scannedPayload(raw?: string | null, data?: string | null): string {
  for (const value of [raw, data]) {
    const text = String(value || "").trim();
    if (text && !/^(null|undefined)$/i.test(text)) return text;
  }
  return "";
}

function safeDecodeURIComponent(value: string): string {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function cleanQrDigits(value: string): string {
  const digits = String(value || "").replace(/\D/g, "").replace(/^0+/, "");
  if (!/^\d{5,11}$/.test(digits)) return "";
  if (/^(19|20)\d{2}$/.test(digits)) return "";
  if (/^(19|20)\d{6}$/.test(digits)) return "";
  return digits;
}

function cleanCedulaNumber(value: string | null | undefined): string {
  return cleanQrDigits(String(value || ""));
}

function normalizeAfiliadoData(response: any): PrintPayload {
  const afiliado = response?.afiliado || (response?.encontrado ? response : null) || {};
  const location = afiliado.ubicacion || afiliado.location || afiliado.direccion || {};
  const municipio = [
    afiliado.municipio,
    afiliado.municipio_sede,
    afiliado.municipio_cedula,
    afiliado.municipio_residencia,
    afiliado.municipio_laboral,
    afiliado.ciudad,
    afiliado.ciudad_trabajo,
    afiliado.localidad,
    afiliado.city,
    location.municipio,
    location.ciudad,
    location.city,
  ].find((value) => String(value || "").trim());
  return {
    nombre: afiliado.nombre_completo || afiliado.nombre || "",
    cargo: afiliado.cargo || "",
    municipio: String(municipio || "").trim(),
    sede: afiliado.sede || "",
  };
}

function parsedFullName(parsed: ParsedCedulaResult): string {
  return [
    parsed.nombres,
    parsed.primer_apellido,
    parsed.segundo_apellido,
  ].filter(Boolean).join(" ").trim();
}

function bestDigitCandidate(value: string): string {
  const candidates: { digits: string; score: number }[] = [];
  const re = /(^|[^\d])(\d[\d\s.,-]{3,20}\d)(?!\d)/g;
  let match: RegExpExecArray | null;
  while ((match = re.exec(value)) !== null) {
    const rawCandidate = match[2];
    const digits = cleanQrDigits(rawCandidate);
    if (!digits) continue;
    const lenScore = ({ 10: 12, 9: 11, 8: 10, 7: 9, 11: 7, 6: 5, 5: 4 } as Record<number, number>)[digits.length] || 1;
    candidates.push({ digits, score: lenScore + (match.index + match[1].length) / Math.max(value.length, 1) });
  }
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0]?.digits || "";
}

function extractQrCedulaPayload(raw: string): string {
  const original = String(raw || "").trim();
  if (!original) return "";

  const variants = Array.from(new Set([
    original,
    safeDecodeURIComponent(original),
    original.replace(/&amp;/gi, "&"),
    safeDecodeURIComponent(original.replace(/&amp;/gi, "&")),
  ])).filter(Boolean);

  for (const value of variants) {
    const direct = cleanQrDigits(value);
    if (direct) return direct;

    const keyMatch = value.match(QR_ID_KEY_RE);
    if (keyMatch) {
      const digits = cleanQrDigits(keyMatch[1]);
      if (digits) return digits;
    }

    const prefixed = value.match(QR_PREFIX_RE);
    if (prefixed) {
      const digits = cleanQrDigits(prefixed[1]);
      if (digits) return digits;
    }

    if (/registraduria\.gov\.co|wsp\.registraduria|ceduladigital|cedula/i.test(value)) {
      const candidate = bestDigitCandidate(value);
      if (candidate) return candidate;
    }

    if (/^\s*\{/.test(value)) {
      try {
        const json = JSON.parse(value);
        const stack = [json];
        while (stack.length) {
          const current = stack.pop();
          if (typeof current === "string" || typeof current === "number") {
            const found = extractQrCedulaPayload(String(current));
            if (found) return found;
          } else if (current && typeof current === "object") {
            stack.push(...Object.values(current as Record<string, unknown>));
          }
        }
      } catch {
        // ignore malformed QR JSON
      }
    }
  }

  return "";
}

function isReliableBarcode(raw: string, currentMode: Mode): boolean {
  const value = String(raw || "").trim();
  if (!value) return false;
  if (currentMode === "manual") return true;
  if (value.includes("PubDSK_") || (value.includes("\u0000") && value.length >= 120)) return true;
  if (isMrzText(value)) return validateMrz(value).valid;
  if (extractQrCedulaPayload(value)) return true;
  if (/^\d{5,11}$/.test(value)) return true;
  if (/registraduria\.gov\.co/i.test(value)) return true;
  if (/[?&](nuip|cedula|cc|doc)[=:]?\d{5,11}/i.test(value)) return true;
  if (/^(?:CC|NUIP|DOC|CEDULA)[:\s]?\d{5,11}$/i.test(value)) return true;
  if (value.includes("PubDSK_") || (value.includes("\u0000") && value.length >= 120)) return true;
  const parsed = parsePdf417(value);
  if (parsed.formato_detectado?.startsWith("pdf417_binario")) return true;
  if (
    currentMode === "camera"
    && parsed.cedula
    && (
      value.includes("IDCOL")
      || value.includes("ICCOL")
      || value.includes("<<")
      || value.includes("|")
      || /C[EÉ]DULA|CC|NUIP|DOCUMENTO|NUMERO|NÚMERO|IDENTIFIC/i.test(value)
      || COLOMBIAN_DASH_PAYLOAD_RE.test(value)
    )
  ) return true;
  if (/^\d{5,11}$/.test(value)) return true;
  if (value.includes("IDCOL") || value.includes("ID<COL") || value.includes("ICCOL") || value.includes("IC<COL")) return true;
  if (COLOMBIAN_DASH_PAYLOAD_RE.test(value)) return true;
  if (/^\d{5,11}\|/.test(value)) return true;
  // QR cédulas nuevas: URL Registraduría o payload con nuip/cedula
  if (/registraduria\.gov\.co/i.test(value)) return true;
  if (/[?&](nuip|cedula|cc|doc)[=:]?\d{5,11}/i.test(value)) return true;
  // QR con solo número precedido de prefijo (ej. "CC1023456789" o "NUIP:1023456789")
  if (/^(?:CC|NUIP|DOC|CEDULA)[:\s]?\d{5,11}$/i.test(value)) return true;
  return false;
}

function normalizeQrCedulaPayload(raw: string): string {
  const value = String(raw || "").trim();
  const extracted = extractQrCedulaPayload(value);
  if (extracted) return extracted;
  const qrUrlMatch = value.match(/[?&](?:nuip|cedula|cc|doc)[=:]?(\d{5,11})/i);
  if (qrUrlMatch) return qrUrlMatch[1];

  const prefixedMatch = value.match(/^(?:CC|NUIP|DOC|CEDULA)[:\s]?(\d{5,11})$/i);
  if (prefixedMatch) return prefixedMatch[1];

  if (/registraduria\.gov\.co/i.test(value)) {
    const digitMatch = value.match(/(\d{7,11})/);
    if (digitMatch) return digitMatch[1];
  }

  return value;
}

function extractCedulaFromCameraPayload(raw: string): string {
  const normalized = normalizeQrCedulaPayload(raw);
  const parsed = parsePdf417(normalized);
  return cleanCedulaNumber(parsed.cedula || extractCedula(normalized) || "");
}

export default function EscanearScreen() {
  const { user } = useSession();
  const isAdmin = user?.role === "admin";
  const router = useRouter();
  const [isFocused, setIsFocused] = useState(false);
  const cameraReadBusy = useRef(false);
  const lookupSequence = useRef(0);
  const {
    eventoId,
    eventoNombre,
    registros,
    misRegistros,
    scan,
    wsStatus,
    duplicadosBloqueados,
    queueSize,
    clearEvento,
  } = useEvento();

  const [mode, setMode] = useState<Mode>("camera");
  const [cedulaInput, setCedulaInput] = useState("");
  const [preview, setPreview] = useState<AfiliadoPreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [ocrLoading, setOcrLoading] = useState(false);
  const [reviewPending, setReviewPending] = useState(false);
  const [documentPreview, setDocumentPreview] = useState<DocumentPreview | null>(null);
  const [scannerEnabled, setScannerEnabled] = useState(true);

  const [permission, requestPermission] = useCameraPermissions();
  const [toast, setToast] = useState<{ kind: "ok" | "dup" | "err"; text: string } | null>(null);
  const [scanFeedback, setScanFeedback] = useState<ScanFeedback | null>(null);
  const lookupMunicipioRef = useRef<{ cedula: string; municipio: string } | null>(null);
  const lastScanRef = useRef<{ value: string; at: number } | null>(null);
  const lastRawScanRef = useRef<{ value: string; at: number } | null>(null);
  const scanBusyRef = useRef(false);
  const ocrLoadingRef = useRef(false);
  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scannerRearmTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flashAnim = useMemo(() => new Animated.Value(0), []);
  const scanLineAnim = useMemo(() => new Animated.Value(0), []);
  const cameraRef = useRef<any>(null);
  const photoSession = useRef({ id: 0 });
  useEffect(() => {
    const session = photoSession.current;
    session.id++;
    return () => { session.id++; };
  }, [mode, isFocused, eventoId]);
  const [reticleHeight, setReticleHeight] = useState(0);

  useFocusEffect(useCallback(() => {
    setIsFocused(true);
    return () => setIsFocused(false);
  }, []));

  const showToast = useCallback((kind: "ok" | "dup" | "err", text: string) => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    setToast({ kind, text });
    toastTimerRef.current = setTimeout(() => setToast(null), PILL_TIMEOUT);
  }, []);

  const flashDuplicate = useCallback(() => {
    flashAnim.setValue(1);
    Animated.timing(flashAnim, { toValue: 0, duration: 600, useNativeDriver: false }).start();
  }, [flashAnim]);

  const rearmScanner = useCallback((delay = SCANNER_REARM_DELAY_MS) => {
    if (scannerRearmTimerRef.current) clearTimeout(scannerRearmTimerRef.current);
    scannerRearmTimerRef.current = setTimeout(() => {
      scannerRearmTimerRef.current = null;
      setScannerEnabled(true);
    }, delay);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
      if (scannerRearmTimerRef.current) clearTimeout(scannerRearmTimerRef.current);
    };
  }, []);

  const buildDocumentPreview = useCallback((cedula: string, parsed: ReturnType<typeof parsePdf417>, fuente?: string): DocumentPreview => {
    const nombre = [
      parsed.nombres,
      parsed.primer_apellido,
      parsed.segundo_apellido,
    ].filter(Boolean).join(" ").trim();
    return {
      cedula,
      nombre,
      fecha: parsed.fecha_nacimiento || parsed.fecha_expiracion || "",
      fechaExpiracion: parsed.fecha_expiracion,
      fuente,
      mrzValido: parsed.mrz_valido,
    };
  }, []);

  useEffect(() => {
  if (mode === "camera" && !permission?.granted && permission?.canAskAgain !== false) {
      requestPermission();
    }
  }, [mode, permission, requestPermission]);

  useEffect(() => {
    if (mode !== "camera") {
      scanLineAnim.stopAnimation();
      scanLineAnim.setValue(0);
      return;
    }

    const animation = Animated.loop(
      Animated.sequence([
        Animated.timing(scanLineAnim, { toValue: 1, duration: 1800, useNativeDriver: true }),
        Animated.timing(scanLineAnim, { toValue: 0, duration: 1800, useNativeDriver: true }),
      ]),
    );
    animation.start();
    return () => animation.stop();
  }, [mode, scanLineAnim]);

  const lookupAfiliado = useCallback(async (cedula: string) => {
    const sequence = ++lookupSequence.current;
    setPreviewLoading(true);
    try {
      const r = await api.lookupAfiliado(cedula);
      if (sequence !== lookupSequence.current) return;
      setPreview({ cedula, ...r, afiliado: { ...r.afiliado, ...normalizeAfiliadoData(r) } });
    } catch {
      if (sequence === lookupSequence.current) setPreview({ encontrado: false, cedula, error: true });
    } finally {
      if (sequence === lookupSequence.current) setPreviewLoading(false);
    }
  }, []);

  const captureCameraBase64 = useCallback(async (quality: number, skipProcessing = true): Promise<string> => {
    if (!cameraRef.current) return "";
    if (typeof cameraRef.current.capture === "function") return cameraRef.current.capture();
    if (typeof cameraRef.current.takePhoto === "function") {
      const photo = await cameraRef.current.takePhoto({ flash: "off" });
      const path = photo?.path ? String(photo.path) : "";
      if (!path) return "";
      const uri = path.startsWith("file://") ? path : `file://${path}`;
      return FileSystem.readAsStringAsync(uri, { encoding: "base64" });
    }

    const photo = await cameraRef.current.takePictureAsync({
      quality,
      base64: true,
      skipProcessing,
    });
    return photo?.base64 || "";
  }, []);

  const readCameraWithOcr = useCallback(async (imageBase64?: string): Promise<OcrReadResult> => {
    if ((!imageBase64 && !cameraRef.current) || ocrLoadingRef.current) return { raw: "" };
    ocrLoadingRef.current = true;
    setOcrLoading(true);
    try {
      const b64 = imageBase64 || await captureCameraBase64(0.72, false);
      if (!b64) return { raw: "" };
      const res = await api.ocrCedula(b64, { localOnly: true });
      if (res.cedula) {
        const raw = res.raw_mrz?.length ? res.raw_mrz.join("\n") : (res.texto_completo || res.cedula);
        const serverParsed = { ...res.parsed, cedula: res.cedula, mrz_valido: res.mrz_valido ?? res.parsed?.mrz_valido };
        return { raw, serverParsed };
      }
      return { raw: "" };
    } catch {
      return { raw: "", error: "No se pudo contactar el respaldo local. Verifica conexión y servidor." };
    } finally {
      ocrLoadingRef.current = false;
      setOcrLoading(false);
    }
  }, [captureCameraBase64]);

  const handleScan = useCallback(
    async (raw: string, options: { serverParsed?: ServerParsedCedula; reviewed?: boolean; source?: string } = {}): Promise<boolean> => {
      if (scanBusyRef.current) return false;
      scanBusyRef.current = true;
      setScannerEnabled(false);
      try {
        const strictMrz = validateMrz(raw);
        const looksMrz = isMrzText(raw);
        if (looksMrz && !strictMrz.valid && !options.reviewed) {
          showToast("err", "MRZ incompleta o sin controles válidos. Mantén la cédula quieta.");
          return false;
        }
        const binaryBarcode = raw.includes("\u0000") || raw.includes("PubDSK_");
        let rawToUse = strictMrz.valid ? strictMrz.lines.join("\n") : binaryBarcode ? raw : normalizeQrCedulaPayload(raw);
        let inheritedServerParsed = options.serverParsed;
        const hasServerParsed = () => !!inheritedServerParsed && Object.keys(inheritedServerParsed).length > 0;
        const canUseServerParsed = () => hasServerParsed() && !!cleanCedulaNumber(inheritedServerParsed?.cedula) && (options.reviewed || strictMrz.valid);
        const buildParsed = (): ParsedCedulaResult => canUseServerParsed()
          ? {
              cedula: inheritedServerParsed?.cedula || "",
              nombres: inheritedServerParsed?.nombres || "",
              primer_apellido: inheritedServerParsed?.primer_apellido || "",
              segundo_apellido: inheritedServerParsed?.segundo_apellido || "",
              genero: inheritedServerParsed?.genero || "",
              fecha_nacimiento: inheritedServerParsed?.fecha_nacimiento || "",
              fecha_expiracion: inheritedServerParsed?.fecha_expiracion || "",
              tipo_sangre: inheritedServerParsed?.tipo_sangre || "",
              formato_detectado: "ocr_servidor",
              mrz_valido: inheritedServerParsed?.mrz_valido,
              raw_mrz: [],
              raw: rawToUse,
            }
          : parsePdf417(rawToUse);
        if (!canUseServerParsed() && !isReliableBarcode(rawToUse, mode)) {
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          showToast("err", mode === "camera"
            ? "Código incompleto. Alinea el documento o toma la foto manualmente para OCR."
            : "No pude confirmar la cédula.");
          return false;
        }

        const parsed = buildParsed();
        const cedula = cleanCedulaNumber(parsed.cedula || extractCedula(rawToUse) || "");
        if (!cedula) {
          setScanFeedback({ kind: "err", title: "NO CONFIRMADA", detail: "No se encontró un número de cédula legible." });
          showToast("err", "No pude confirmar la cédula. Usa la camara completa o manual.");
          return false;
        }
        setDocumentPreview(buildDocumentPreview(cedula, parsed, parsed.formato_detectado || "camara"));
        const now = Date.now();
        if (lastScanRef.current && lastScanRef.current.value === cedula && now - lastScanRef.current.at < 1500) {
          return false;
        }
        lastScanRef.current = { value: cedula, at: now };

        const previewSequence = ++lookupSequence.current;
        setPreview(null);
        setPreviewLoading(true);
        void api.lookupAfiliado(cedula)
          .then((afiliadoResponse) => {
            const lookupPrint = normalizeAfiliadoData(afiliadoResponse);
            lookupMunicipioRef.current = {
              cedula,
              municipio: lookupPrint.municipio || "No registrado en la base",
            };
            if (previewSequence === lookupSequence.current) {
              setPreview({ cedula, ...afiliadoResponse, afiliado: { ...afiliadoResponse.afiliado, ...lookupPrint } });
              setScanFeedback((current) => current?.cedula === cedula
                ? { ...current, municipio: lookupPrint.municipio || "No registrado en la base" }
                : current);
            }
          })
          .catch(() => {
            lookupMunicipioRef.current = { cedula, municipio: "Sin verificar" };
            if (previewSequence === lookupSequence.current) {
              setPreview({ encontrado: false, cedula, error: true });
              setScanFeedback((current) => current?.cedula === cedula
                ? { ...current, municipio: "Sin verificar" }
                : current);
            }
          })
          .finally(() => {
            if (previewSequence === lookupSequence.current) setPreviewLoading(false);
          });

        const res = await scan(cedula, {
          nombre: parsedFullName(parsed),
          cargo: "",
          municipio: "",
          sede: "",
          raw_barcode: rawToUse,
          capture_source: options.source || (strictMrz.valid ? "mrz_local" : options.reviewed ? "ocr_reviewed" : mode === "manual" ? "manual" : "barcode"),
          primer_apellido: parsed.primer_apellido,
          segundo_apellido: parsed.segundo_apellido,
          nombres: parsed.nombres,
          genero: parsed.genero,
          fecha_nacimiento: parsed.fecha_nacimiento,
          fecha_expiracion: parsed.fecha_expiracion,
          tipo_sangre: parsed.tipo_sangre,
        } as any);
        if (res.ok) {
          const pendingSync = res.mensaje.includes("pendiente") || res.mensaje.includes("sincronizando");
          const municipio = lookupMunicipioRef.current?.cedula === cedula
            ? lookupMunicipioRef.current.municipio
            : "Consultando…";
          setScanFeedback({
            kind: "ok",
            title: "REGISTRO CONFIRMADO",
            cedula,
            municipio,
            detail: pendingSync ? "Guardada en este teléfono · pendiente de sincronización" : "Guardada y sincronizada correctamente",
          });
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          showToast("ok", pendingSync
            ? `Cédula ${cedula}: guardada en el teléfono; falta sincronizar`
            : `Cédula ${cedula} registrada`);
        } else if (res.duplicate) {
          const municipio = lookupMunicipioRef.current?.cedula === cedula
            ? lookupMunicipioRef.current.municipio
            : "Consultando…";
          setScanFeedback({ kind: "dup", title: "REGISTRO DUPLICADO", cedula, municipio, detail: "Esta cédula ya fue registrada para el evento." });
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          flashDuplicate();
          showToast("dup", `Atención: ${cedula} ya registrada`);
        } else {
          setScanFeedback({ kind: "err", title: "NO CONFIRMADA", cedula, municipio: "Sin verificar", detail: res.mensaje || "No se pudo guardar el registro." });
          await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
          showToast("err", res.mensaje);
        }
        return !!(res.ok || res.duplicate);
      } catch {
        showToast("err", "No se pudo completar el registro. Puedes volver a presentar la cédula.");
        return false;
      } finally {
        scanBusyRef.current = false;
        if (mode === "camera") rearmScanner();
      }
    },
    [mode, scan, showToast, flashDuplicate, buildDocumentPreview, rearmScanner],
  );

  const offerGeminiBackup = useCallback((image: string, ticket: number) => {
    if (ticket !== photoSession.current.id) return;
    setReviewPending(true);
    Alert.alert("Respaldo opcional con Gemini",
      "La lectura local no fue suficiente. Si eliges continuar, esta foto se enviará a Google y puede consumir cuota o generar un cargo de API. El resultado siempre necesitará tu revisión.",
      [{ text: "Seguir con lectura local", style: "cancel", onPress: () => setReviewPending(false) },
       { text: "Usar Gemini con esta foto", onPress: () => {
         if (ticket !== photoSession.current.id) { setReviewPending(false); return; }
         setReviewPending(false); setOcrLoading(true); cameraReadBusy.current = true;
         void api.geminiBackup(image).then(result => {
           if (ticket !== photoSession.current.id) return;
           if (!result.ok || !result.cedula) {
             showToast("err", result.error === "gemini_no_configurado" ? "El respaldo con Gemini no está habilitado." : "El respaldo no pudo confirmar datos legibles. Usa lectura local o entrada manual.");
             return;
           }
           const candidate: ServerParsedCedula = { ...result.parsed, cedula: result.cedula, mrz_valido: false };
           setReviewPending(true);
           Alert.alert("Revisar resultado de Gemini", `Compara con el documento antes de registrar:\n\n${candidate.cedula}\n${[candidate.nombres, candidate.primer_apellido, candidate.segundo_apellido].filter(Boolean).join(" ")}\n${candidate.fecha_nacimiento || "Fecha no leída"}`,
             [{ text: "Descartar", style: "cancel", onPress: () => setReviewPending(false) },
              { text: "Datos correctos: registrar", onPress: () => {
                setReviewPending(false);
                if (ticket === photoSession.current.id) void handleScan(candidate.cedula || "", { serverParsed: candidate, reviewed: true, source: "gemini_reviewed" });
              }}], { cancelable: false });
         }).catch(() => { if (ticket === photoSession.current.id) showToast("err", "No se pudo conectar con el respaldo de Gemini."); })
           .finally(() => { cameraReadBusy.current = false; setOcrLoading(false); });
       }}], { cancelable: false });
  }, [handleScan, showToast]);

  const captureAndDecodeBarcode = useCallback(async (silent = false) => {
    if (!cameraRef.current || cameraReadBusy.current || scanBusyRef.current) return;
    cameraReadBusy.current = true;
    const ticket = photoSession.current.id;
    try {
      const imageBase64 = await captureCameraBase64(0.65);
      if (!imageBase64) {
        if (!silent) showToast("err", "No pude tomar la imagen. Intenta de nuevo.");
        return;
      }

      if (!silent) showToast("err", "Procesando la foto...");
      // QR/PDF417 se leen directamente mientras la cámara está abierta.
      // Este botón queda reservado para OCR/MRZ de la foto tomada por el usuario.
      const ocrResult = await readCameraWithOcr(imageBase64);
      if (ticket !== photoSession.current.id) return;
      if (ocrResult.error) { showToast("err", ocrResult.error); return; }
      if (ocrResult.raw && ocrResult.serverParsed?.cedula) {
        const validation = validateMrz(ocrResult.raw);
        if (validation.valid && ocrResult.serverParsed.mrz_valido) await handleScan(validation.lines.join("\n"), { source: "mrz_photo" });
        else {
          const candidate = ocrResult.serverParsed;
          setReviewPending(true);
          Alert.alert("Revisar lectura", `Compara estos datos con la cédula antes de registrar:\n\n${candidate.cedula}\n${[candidate.nombres, candidate.primer_apellido, candidate.segundo_apellido].filter(Boolean).join(" ")}\n${candidate.fecha_nacimiento || "Fecha no leída"}`,
            [{ text: "Cancelar", style: "cancel", onPress: () => setReviewPending(false) }, { text: "Releer con Gemini", onPress: () => offerGeminiBackup(imageBase64, ticket) }, { text: "Datos correctos: registrar", onPress: () => { setReviewPending(false); if (ticket === photoSession.current.id) void handleScan(candidate.cedula || "", { serverParsed: candidate, reviewed: true, source: "ocr_reviewed" }); } }], { cancelable: false });
        }
        return;
      }

      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      if (!silent) offerGeminiBackup(imageBase64, ticket);
    } catch {
      if (!silent) showToast("err", "No pude validar la MRZ. Alinea la cédula frente a la cámara.");
    } finally {
      cameraReadBusy.current = false;
    }
  }, [captureCameraBase64, handleScan, readCameraWithOcr, offerGeminiBackup, showToast]);

  // Auto-lookup as user types in manual mode (debounced)
  useEffect(() => {
    lookupSequence.current++;
    if (mode !== "manual") return;
    const cedula = extractCedula(cedulaInput);
    if (!cedula || cedula.length < 6) {
      const clear = setTimeout(() => { setPreview(null); setPreviewLoading(false); }, 0);
      return () => clearTimeout(clear);
    }
    const id = setTimeout(() => lookupAfiliado(cedula), 350);
    return () => clearTimeout(id);
  }, [cedulaInput, mode, lookupAfiliado]);

  const onManualSubmit = async () => {
    const cedula = extractCedula(cedulaInput);
    if (!cedula) {
      Alert.alert("Cédula inválida", "Ingresa un número entre 6 y 11 dígitos");
      return;
    }
    await handleScan(cedula);

  };


  const statusColor = wsStatus === "online" ? theme.success : wsStatus === "connecting" ? theme.warning : theme.error;
  const statusLabel = wsStatus === "online" ? "En linea" : wsStatus === "connecting" ? "Conectando..." : "Sin tiempo real";
  const recientes = useMemo(() => registros.slice(0, 5), [registros]);

  if (!eventoId) {
    return (
      <SafeAreaView style={styles.container} edges={["top", "left", "right"]}>
        <View style={styles.emptyWrap}>
          <Ionicons name="calendar-outline" size={64} color={theme.textDisabled} />
          <Text style={styles.emptyTitle}>Selecciona un evento</Text>
          <Text style={styles.emptySub}>Necesitas un evento activo para escanear cédulas.</Text>
          <TouchableOpacity testID="go-to-eventos" style={styles.primaryBtn} onPress={() => router.push("/(app)/eventos")}>
            <Text style={styles.primaryBtnText}>Ir a Eventos</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const flashBg = flashAnim.interpolate({ inputRange: [0, 1], outputRange: ["rgba(255,59,48,0)", "rgba(255,59,48,0.35)"] });
  const scanLineTranslateY = scanLineAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, Math.max(reticleHeight - 3, 0)],
  });

  return (
    <SafeAreaView style={styles.container} edges={["top", "left", "right"]}>
      <Animated.View pointerEvents="none" style={[ABSOLUTE_FILL, { backgroundColor: flashBg, zIndex: 100 }]} />

      <View style={styles.topBar}>
        <View style={{ flex: 1 }}>
          <Text style={styles.eventTitle} numberOfLines={1}>{eventoNombre}</Text>
          <View style={styles.statusRow}>
            <View style={[styles.dot, { backgroundColor: statusColor }]} />
            <Text testID="sync-status-indicator" style={[styles.statusText, { color: statusColor }]}>{statusLabel}</Text>
            <Text style={styles.statusMeta}>{queueSize > 0 ? " · sincronización pendiente" : " · sincronizado"}</Text>
          </View>
        </View>
        <View style={styles.topActions}>
          <TouchableOpacity testID="change-event-button" style={styles.switchEventBtn} onPress={clearEvento}>
            <Ionicons name="swap-horizontal" size={18} color={theme.text} />
          </TouchableOpacity>
          <View style={styles.counterPill}>
            <Text testID="scan-counter" style={styles.counterValue}>{misRegistros}</Text>
            <Text style={styles.counterLabel}>mis escaneos</Text>
          </View>
        </View>
      </View>

      <View style={styles.modeRow}>
        <TouchableOpacity
          testID="mode-camera-toggle"
          style={[styles.modeBtn, mode === "camera" && styles.modeBtnActive]}
          onPress={() => setMode("camera")}
        >
          <Ionicons name="scan" size={16} color={mode === "camera" ? "#fff" : theme.textSecondary} />
          <Text style={[styles.modeText, mode === "camera" && { color: "#fff" }]}>Camara</Text>
        </TouchableOpacity>
        <TouchableOpacity
          testID="manual-entry-toggle"
          style={[styles.modeBtn, mode === "manual" && styles.modeBtnActive]}
          onPress={() => setMode("manual")}
        >
          <Ionicons name="keypad" size={16} color={mode === "manual" ? "#fff" : theme.textSecondary} />
          <Text style={[styles.modeText, mode === "manual" && { color: "#fff" }]}>Manual</Text>
        </TouchableOpacity>
      </View>

      {scanFeedback && mode === "camera" && (
        <View
          accessibilityLiveRegion="polite"
          testID="scan-confirmation-card"
          style={[styles.confirmationCard, styles[`confirmation${scanFeedback.kind}`]]}
        >
          <Ionicons
            name={scanFeedback.kind === "ok" ? "checkmark-circle" : scanFeedback.kind === "dup" ? "alert-circle" : "close-circle"}
            size={34}
            color="#fff"
          />
          <View style={styles.confirmationCopy}>
            <Text style={styles.confirmationTitle}>{scanFeedback.title}</Text>
            {!!scanFeedback.cedula && <Text style={styles.confirmationCedula}>Documento: CC {scanFeedback.cedula}</Text>}
            {!!scanFeedback.municipio && <Text style={styles.confirmationMunicipio}>Municipio: {scanFeedback.municipio}</Text>}
            <Text style={styles.confirmationDetail}>{scanFeedback.detail}</Text>
          </View>
          <TouchableOpacity
            accessibilityLabel="Cerrar confirmación"
            onPress={() => setScanFeedback(null)}
            style={styles.confirmationClose}
          >
            <Ionicons name="close" size={20} color="rgba(255,255,255,0.8)" />
          </TouchableOpacity>
        </View>
      )}

      {mode === "camera" && isFocused ? (
        <View style={styles.cameraWrap} testID="scanner-camera-view">
          {!permission ? (
            <View style={styles.camPlaceholder}><Text style={styles.permText}>Iniciando cámara...</Text></View>
          ) : !permission.granted ? (
            <View style={styles.camPlaceholder}>
              <Ionicons name="camera-outline" size={56} color={theme.textSecondary} />
              <Text style={styles.permTitle}>Acceso a la cámara</Text>
              <Text style={styles.permText}>Para leer PDF417, QR, MRZ o numero impreso.</Text>
              <TouchableOpacity testID="grant-camera-permission" style={styles.primaryBtn} onPress={() => requestPermission()}>
                <Text style={styles.primaryBtnText}>Otorgar permiso</Text>
              </TouchableOpacity>
            </View>
          ) : localScannerAvailable ? (
            <LocalCedulaCamera ref={cameraRef} style={ABSOLUTE_FILL}
              active={scannerEnabled && !ocrLoading && !reviewPending}
              onMrz={(raw) => scanBusyRef.current || cameraReadBusy.current ? Promise.resolve(false) : handleScan(raw, { source: "mrz_local" })}
              onBarcode={(raw, type) => {
                if (scanBusyRef.current || cameraReadBusy.current) return false;
                const now = Date.now();
                if (lastRawScanRef.current?.value === raw && now-lastRawScanRef.current.at < RAW_SCAN_COOLDOWN_MS) return false;
                lastRawScanRef.current = { value: raw, at: now };
                if (type === "qr" && !extractCedulaFromCameraPayload(raw)) {
                  showToast("err", "QR sin identidad legible. Presenta las tres líneas MRZ.");
                  return false;
                }
                void handleScan(raw, { source: "barcode" });
                return true;
              }}>
              <View style={styles.reticleOverlay} pointerEvents="none">
                <View style={[styles.reticle, styles.backReticle]}>
                  <View style={[styles.reticleCorner, styles.reticleCornerTopLeft]} />
                  <View style={[styles.reticleCorner, styles.reticleCornerTopRight]} />
                  <View style={[styles.reticleCorner, styles.reticleCornerBottomLeft]} />
                  <View style={[styles.reticleCorner, styles.reticleCornerBottomRight]} />
                  <View style={styles.mrzGuide}><View style={styles.mrzGuideLine} /><View style={styles.mrzGuideLine} /><View style={styles.mrzGuideLine} /></View>
                </View>
                <Text style={styles.reticleHint}>Lectura automática en el teléfono · MRZ y PDF417</Text>
              </View>
              <View style={styles.captureBar}>
                <TouchableOpacity style={styles.captureBtn} disabled={ocrLoading || reviewPending}
                  onPress={() => { void captureAndDecodeBarcode(false); }}>
                  {ocrLoading ? <ActivityIndicator color="#fff" /> : <Text style={styles.captureBtnText}>Foto de respaldo y revisión</Text>}
                </TouchableOpacity>
              </View>
            </LocalCedulaCamera>
          ) : (
            <CameraView
  ref={cameraRef}
  style={ABSOLUTE_FILL}
  facing="back"
  autofocus="on"
  barcodeScannerSettings={{
    barcodeTypes: ["pdf417", "qr"],
  }}
  onBarcodeScanned={scannerEnabled && !reviewPending ? ({ raw, data, type }) => {
    const payload = scannedPayload(raw, data);
    if (!payload) return;
    const normalized = normalizeQrCedulaPayload(payload);
    const now = Date.now();
    if (
      lastRawScanRef.current
      && lastRawScanRef.current.value === normalized
      && now - lastRawScanRef.current.at < RAW_SCAN_COOLDOWN_MS
    ) {
      return;
    }
    lastRawScanRef.current = { value: normalized, at: now };
    const hasDirectCedula = !!extractCedulaFromCameraPayload(normalized);
    if (!hasDirectCedula) {
      // Algunas licencias traen la identidad dentro del PDF417 codificado y
      // no exponen la cédula en el texto plano. Dejamos que el parser local
      // intente resolver el payload completo antes de pedir una foto.
      if (type === "pdf417" && normalized.length >= 20) {
        void handleScan(normalized);
        return;
      }
      if (type === "qr") showToast("err", "QR detectado pero sin cédula legible. Usa PDF417, MRZ o manual.");
      return;
    }
    void handleScan(normalized);
              } : undefined}>
              <View style={styles.reticleOverlay} pointerEvents="none">
                <View
                  style={[styles.reticle, styles.backReticle]}
                  onLayout={({ nativeEvent }) => setReticleHeight(nativeEvent.layout.height)}
                >
                  <Animated.View style={[styles.scanLine, { transform: [{ translateY: scanLineTranslateY }] }]} />
                  <View style={[styles.reticleCorner, styles.reticleCornerTopLeft]} />
                  <View style={[styles.reticleCorner, styles.reticleCornerTopRight]} />
                  <View style={[styles.reticleCorner, styles.reticleCornerBottomLeft]} />
                  <View style={[styles.reticleCorner, styles.reticleCornerBottomRight]} />
                  <View style={styles.qrGuide} />
                  <View style={styles.mrzGuide}>
                    <View style={styles.mrzGuideLine} />
                    <View style={styles.mrzGuideLine} />
                    <View style={styles.mrzGuideLine} />
                  </View>
                </View>
                <Text style={styles.reticleHint}>Alinea el documento dentro del marco y pulsa el botón para tomar una foto.</Text>
              </View>
              <View style={styles.captureBar}>
                <TouchableOpacity
                  testID="decode-pdf417-photo-btn"
                  style={[styles.captureBtn, (ocrLoading) && { opacity: 0.6 }]}
                  onPress={() => { void captureAndDecodeBarcode(false); }}
                  disabled={ocrLoading || reviewPending}
                >
                  {ocrLoading ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <>
                      <Ionicons name="camera" size={24} color="#fff" />
                      <Text style={styles.captureBtnText}>Tomar foto y leer</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </CameraView>
          )}
        </View>
      ) : (
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{ flex: 1 }}>
          <ScrollView contentContainerStyle={styles.manualScroll} keyboardShouldPersistTaps="handled">
            <View style={styles.manualCard}>
              <Text style={styles.manualLabel}>Cédula</Text>
              <TextInput
                testID="manual-cedula-input"
                style={[styles.manualInput, { fontSize: 28, fontWeight: "900", letterSpacing: 2, textAlign: "center" }]}
                value={cedulaInput}
                onChangeText={(t) => setCedulaInput(t.replace(/\D/g, ""))}
                placeholder="123456789"
                placeholderTextColor={theme.textDisabled}
                keyboardType="number-pad"
                autoFocus
                maxLength={11}
              />

              <TouchableOpacity testID="manual-submit-button" style={styles.submitBtn} onPress={onManualSubmit}>
                <Ionicons name="checkmark-circle" size={22} color="#fff" />
                <Text style={styles.submitBtnText}>Registrar</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      )}

      {/* In manual mode keep the input and register button above the feedback
          card so the next document can be entered without losing the field. */}
      {scanFeedback && mode === "manual" && (
        <View
          accessibilityLiveRegion="polite"
          testID="scan-confirmation-card"
          style={[styles.confirmationCard, styles[`confirmation${scanFeedback.kind}`]]}
        >
          <Ionicons
            name={scanFeedback.kind === "ok" ? "checkmark-circle" : scanFeedback.kind === "dup" ? "alert-circle" : "close-circle"}
            size={34}
            color="#fff"
          />
          <View style={styles.confirmationCopy}>
            <Text style={styles.confirmationTitle}>{scanFeedback.title}</Text>
            {!!scanFeedback.cedula && <Text style={styles.confirmationCedula}>Documento: CC {scanFeedback.cedula}</Text>}
            {!!scanFeedback.municipio && <Text style={styles.confirmationMunicipio}>Municipio: {scanFeedback.municipio}</Text>}
            <Text style={styles.confirmationDetail}>{scanFeedback.detail}</Text>
          </View>
          <TouchableOpacity
            accessibilityLabel="Cerrar confirmación"
            onPress={() => setScanFeedback(null)}
            style={styles.confirmationClose}
          >
            <Ionicons name="close" size={20} color="rgba(255,255,255,0.8)" />
          </TouchableOpacity>
        </View>
      )}

      {(previewLoading || preview) && (
        <View accessibilityLiveRegion="polite" testID="docente-result" style={[styles.teacherCard, { backgroundColor: previewLoading || preview?.error ? "#334155" : preview?.encontrado ? "#14532d" : "#991b1b" }]}>
          <View style={styles.teacherHeader}>
            {!previewLoading && (
              <Ionicons
                name={preview?.encontrado ? "checkmark-circle" : preview?.error ? "help-circle" : "close-circle"}
                size={38}
                color="#fff"
              />
            )}
            <Text style={styles.teacherAnswer}>{previewLoading ? "CONSULTANDO DOCENTE…" : preview?.error ? "DOCENTE: SIN VERIFICAR" : preview?.encontrado ? "DOCENTE: SÍ" : "DOCENTE: NO"}</Text>
          </View>
          {!!preview && <Text style={styles.teacherDocument}>Documento: CC {preview.cedula}</Text>}
          {!!preview?.afiliado?.nombre && <Text style={styles.teacherName} numberOfLines={2}>{preview.afiliado.nombre}</Text>}
          {!previewLoading && <Text numberOfLines={1} ellipsizeMode="tail" style={styles.teacherMunicipality}>Municipio: {preview?.error ? "Sin verificar" : preview?.afiliado?.municipio || "No registrado en la base"}</Text>}
          {!previewLoading && !preview?.error && preview && (
            <Text
              testID="aportes-status"
              style={[styles.aportesStatus, { color: preview.encontrado ? "#86efac" : "#fecaca" }]}
            >
              {preview.encontrado ? "INSCRITO" : "NO INSCRITO"}
            </Text>
          )}
          {preview?.error && <Text style={styles.teacherDetail}>No se pudo consultar la base. Comprueba la conexión.</Text>}
        </View>
      )}

      {documentPreview && (
        <View style={styles.documentPreview}>
          <View style={styles.documentPreviewHeader}>
            <Ionicons name="card-outline" size={17} color={theme.brand} />
            <Text style={styles.documentPreviewTitle}>Lectura documento</Text>
            {!!documentPreview.fuente && <Text style={styles.documentPreviewSource}>{documentPreview.fuente}</Text>}
          </View>
          <View style={styles.documentPreviewGrid}>
            <View style={styles.documentPreviewCell}>
              <Text style={styles.documentPreviewLabel}>Número de documento</Text>
              <Text style={styles.documentPreviewValue}>CC {documentPreview.cedula || "No detectado"}</Text>
            </View>
            <View style={styles.documentPreviewCell}>
              <Text style={styles.documentPreviewLabel}>Fecha</Text>
              <Text style={styles.documentPreviewValue}>{documentPreview.fecha || "-"}</Text>
            </View>
          </View>
          {!!documentPreview.nombre && <Text style={styles.documentPreviewName} numberOfLines={1}>{documentPreview.nombre}</Text>}
          {!!documentPreview.fechaExpiracion && documentPreview.fechaExpiracion !== documentPreview.fecha && (
            <Text style={styles.documentPreviewMeta}>Vence {documentPreview.fechaExpiracion}</Text>
          )}
        </View>
      )}

      {/* Recientes */}
      <View style={styles.recentWrap}>
        <View style={styles.recentHeader}>
          <Text style={styles.recentTitle}>Recientes</Text>
            {isAdmin && <Text style={styles.recentMeta}>{duplicadosBloqueados} duplicados bloqueados</Text>}
        </View>
        <FlatList
          data={recientes}
          keyExtractor={(it) => it.id}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}
          ListEmptyComponent={<Text style={styles.recentEmpty}>Aún no hay escaneos.</Text>}
          renderItem={({ item }) => (
            <View style={styles.recentChip}>
              <Text style={styles.recentCedula}>{item.cedula}</Text>
              <Text style={[styles.recentField, { fontSize: 19, fontWeight: "900" }]}>{item.es_afiliado == null ? "Docente: sin verificar" : item.es_afiliado ? "DOCENTE: SÍ" : "DOCENTE: NO"}</Text>
              {!!item.nombre && <Text style={styles.recentName} numberOfLines={1}>{item.nombre}</Text>}
              {!!item.cargo && <Text style={styles.recentField} numberOfLines={1}>{item.cargo}</Text>}
              {!!item.municipio && <Text style={styles.recentField} numberOfLines={1}>{item.municipio}</Text>}
            </View>
          )}
        />
      </View>

      {toast && (
        <View
          testID="scan-toast"
          style={[
            styles.toast,
            toast.kind === "ok" && { backgroundColor: theme.successBg, borderColor: theme.success },
            toast.kind === "dup" && { backgroundColor: theme.errorBg, borderColor: theme.error },
            toast.kind === "err" && { backgroundColor: theme.warningBg, borderColor: theme.warning },
          ]}
        >
          <Text style={styles.toastText}>{toast.text}</Text>
        </View>
      )}

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  teacherCard: { marginHorizontal: 16, marginVertical: 6, paddingHorizontal: 14, paddingVertical: 12, borderRadius: 16, gap: 4 },
  teacherHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  teacherAnswer: { color: "#fff", fontSize: 25, fontWeight: "900", flexShrink: 1 },
  teacherDocument: { color: "rgba(255,255,255,0.92)", fontSize: 16, fontWeight: "800", letterSpacing: 0.2 },
  teacherName: { color: "#fff", fontSize: 21, lineHeight: 25, fontWeight: "900", marginTop: 1 },
  teacherDetail: { color: "#fff", fontSize: 15 },
  teacherMunicipality: { color: "#fff", fontSize: 16, fontWeight: "700" },
  aportesStatus: { color: "#fde68a", fontSize: 15, fontWeight: "900", marginTop: 4, letterSpacing: 1.1 },
  container: { flex: 1, backgroundColor: theme.bg },
  topBar: { flexDirection: "row", paddingHorizontal: 14, paddingTop: 6, paddingBottom: 8, alignItems: "center", gap: 10 },
  eventTitle: { color: theme.text, fontSize: 17, fontWeight: "900" },
  statusRow: { flexDirection: "row", alignItems: "center", marginTop: 4 },
  dot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  statusText: { fontWeight: "700", fontSize: 12 },
  statusMeta: { color: theme.textDisabled, fontSize: 11 },
  topActions: { flexDirection: "row", alignItems: "center", gap: 8 },
  switchEventBtn: {
    width: 40,
    height: 40,
    borderRadius: 8,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.surface,
    borderWidth: 1,
    borderColor: theme.border,
  },
  counterPill: { backgroundColor: theme.surface, borderWidth: 1, borderColor: theme.border, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 7, alignItems: "center" },
  counterValue: { color: theme.text, fontSize: 22, fontWeight: "900" },
  counterLabel: { color: theme.textDisabled, fontSize: 9, textTransform: "uppercase", letterSpacing: 1 },
  modeRow: { flexDirection: "row", marginHorizontal: 14, marginBottom: 8, backgroundColor: theme.surface, borderRadius: 8, padding: 3, borderWidth: 1, borderColor: theme.border },
  modeBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 9, borderRadius: 6, gap: 6 },
  modeBtnActive: { backgroundColor: theme.brand },
  modeText: { color: theme.textSecondary, fontWeight: "700", fontSize: 13 },
  cameraWrap: { flex: 1, marginHorizontal: 8, borderRadius: 8, overflow: "hidden", backgroundColor: "#000", borderWidth: 1, borderColor: theme.border },
  camPlaceholder: { flex: 1, alignItems: "center", justifyContent: "center", padding: 24, gap: 12 },
  permTitle: { color: theme.text, fontSize: 18, fontWeight: "800" },
  permText: { color: theme.textSecondary, fontSize: 13, textAlign: "center" },
  reticleOverlay: { ...ABSOLUTE_FILL, alignItems: "center", justifyContent: "center", paddingHorizontal: 16 },
  reticle: { width: "100%", maxWidth: 720, aspectRatio: 1.586, borderRadius: 8, overflow: "hidden", backgroundColor: "rgba(0,0,0,0.12)" },
  backReticle: { justifyContent: "space-between", padding: 16 },
  scanLine: { position: "absolute", top: 0, left: 0, right: 0, height: 3, backgroundColor: theme.brandNeon, opacity: 0.95, shadowColor: theme.brandNeon, shadowOpacity: 0.8, shadowOffset: { width: 0, height: 0 }, shadowRadius: 8, zIndex: 3 },
  reticleCorner: { position: "absolute", width: 38, height: 38, borderColor: "#fff", zIndex: 4 },
  reticleCornerTopLeft: { top: 0, left: 0, borderTopWidth: 3, borderLeftWidth: 3 },
  reticleCornerTopRight: { top: 0, right: 0, borderTopWidth: 3, borderRightWidth: 3 },
  reticleCornerBottomLeft: { bottom: 0, left: 0, borderBottomWidth: 3, borderLeftWidth: 3 },
  reticleCornerBottomRight: { bottom: 0, right: 0, borderBottomWidth: 3, borderRightWidth: 3 },
  qrGuide: { alignSelf: "flex-end", width: "22%", aspectRatio: 1, borderWidth: 2, borderColor: "#fff", borderRadius: 6, backgroundColor: "rgba(255,255,255,0.08)" },
  mrzGuide: { gap: 5 },
  mrzGuideLine: { height: 6, borderRadius: 3, backgroundColor: "rgba(255,255,255,0.75)" },
  reticleHint: { color: "#fff", marginTop: 12, backgroundColor: "rgba(0,0,0,0.6)", paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, fontSize: 12 },
  captureBar: { position: "absolute", bottom: 24, left: 0, right: 0, alignItems: "center" },
  captureBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: theme.brand,
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 8,
    shadowColor: theme.brand,
    shadowOpacity: 0.5,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 12,
    elevation: 6,
  },
  captureBtnText: { color: "#fff", fontWeight: "800", fontSize: 15 },
  manualScroll: { padding: 16, paddingBottom: 24 },
  manualCard: { backgroundColor: theme.surface, borderRadius: 8, padding: 16, borderWidth: 1, borderColor: theme.border, gap: 8 },
  manualLabel: { color: theme.textSecondary, fontSize: 11, fontWeight: "700", letterSpacing: 1.2, textTransform: "uppercase", marginTop: 10 },
  manualInput: { backgroundColor: theme.bg, borderWidth: 1, borderColor: theme.border, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 16, color: theme.text, fontSize: 15 },
  previewWrap: { marginTop: 12, padding: 12, borderWidth: 1, borderColor: theme.border, borderRadius: 8, gap: 4 },
  previewTitle: { fontSize: 12, fontWeight: "900", letterSpacing: 1.2, textTransform: "uppercase" },
  previewName: { color: theme.text, fontWeight: "800", fontSize: 16, marginTop: 4 },
  previewMeta: { color: theme.textSecondary, fontSize: 13 },
  submitBtn: { flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 8, backgroundColor: theme.brand, paddingVertical: 16, borderRadius: 8, marginTop: 16 },
  submitBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
  documentPreview: { marginHorizontal: 14, marginTop: 10, padding: 12, backgroundColor: theme.surface, borderWidth: 1, borderColor: theme.border, borderRadius: 8, gap: 8 },
  documentPreviewHeader: { flexDirection: "row", alignItems: "center", gap: 6 },
  documentPreviewTitle: { color: theme.text, fontWeight: "900", fontSize: 12, textTransform: "uppercase", letterSpacing: 1 },
  documentPreviewSource: { marginLeft: "auto", color: theme.textDisabled, fontWeight: "700", fontSize: 11 },
  documentPreviewGrid: { flexDirection: "row", gap: 8 },
  documentPreviewCell: { flex: 1, backgroundColor: theme.bg, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 8 },
  documentPreviewLabel: { color: theme.textDisabled, fontSize: 10, fontWeight: "800", textTransform: "uppercase", letterSpacing: 1 },
  documentPreviewValue: { color: theme.text, fontSize: 15, fontWeight: "900", marginTop: 2 },
  documentPreviewName: { color: theme.textSecondary, fontSize: 13, fontWeight: "700" },
  documentPreviewMeta: { color: theme.textDisabled, fontSize: 11 },
  recentWrap: { paddingTop: 12, paddingBottom: 8, borderTopWidth: 1, borderColor: theme.border, backgroundColor: theme.bg },
  recentHeader: { flexDirection: "row", justifyContent: "space-between", paddingHorizontal: 20, marginBottom: 8 },
  recentTitle: { color: theme.text, fontWeight: "800", fontSize: 13, textTransform: "uppercase", letterSpacing: 1 },
  recentMeta: { color: theme.error, fontSize: 11, fontWeight: "700" },
  recentEmpty: { color: theme.textDisabled, fontSize: 12, paddingHorizontal: 16 },
  recentChip: { backgroundColor: theme.surface, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderColor: theme.border, minWidth: 148, maxWidth: 220 },
  recentCedula: { color: theme.text, fontWeight: "800", fontSize: 14 },
  recentName: { color: theme.textSecondary, fontSize: 11, marginTop: 2 },
  recentField: { color: theme.textDisabled, fontSize: 10, marginTop: 1 },
  toast: { position: "absolute", top: 80, left: 20, right: 20, padding: 14, borderRadius: 14, borderWidth: 1, zIndex: 200 },
  toastText: { color: theme.text, fontWeight: "800", fontSize: 14, textAlign: "center" },
  confirmationCard: { marginHorizontal: 14, marginBottom: 8, padding: 14, borderRadius: 14, flexDirection: "row", alignItems: "center", gap: 11, borderWidth: 1, borderColor: "rgba(255,255,255,0.24)" },
  confirmationok: { backgroundColor: "#16803c" },
  confirmationdup: { backgroundColor: "#b45309" },
  confirmationerr: { backgroundColor: "#b42318" },
  confirmationCopy: { flex: 1, gap: 2 },
  confirmationTitle: { color: "#fff", fontSize: 17, fontWeight: "900", letterSpacing: 0.3 },
  confirmationCedula: { color: "#fff", fontSize: 16, fontWeight: "800" },
  confirmationMunicipio: { color: "#fff", fontSize: 15, fontWeight: "700" },
  confirmationDetail: { color: "rgba(255,255,255,0.9)", fontSize: 12, lineHeight: 17 },
  confirmationClose: { padding: 4 },
  emptyWrap: { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, gap: 12 },
  emptyTitle: { color: theme.text, fontSize: 20, fontWeight: "800" },
  emptySub: { color: theme.textSecondary, textAlign: "center" },
  primaryBtn: { backgroundColor: theme.brand, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12, marginTop: 12 },
  primaryBtnText: { color: "#fff", fontWeight: "800", fontSize: 15 },
});
